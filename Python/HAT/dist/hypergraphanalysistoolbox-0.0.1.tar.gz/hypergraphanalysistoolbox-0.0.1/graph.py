import numpy as np
import scipy as sp

class graph:

    def __init__(self):
        self.A = np.zeros((0,0))
        self.N = 0
        self.E = 0
        
    def __init__(self, A):
        self.A = A
        self.N = len(A)
    
    @property
    def degree(self):
        return np.diag(sum(self.A))
        
    @property
    def laplacian(self):
        return self.degree - self.A

    @property
    def clusteringCoef(self):
        """
        The clustering coefficient of the graph.
        """
        gammas = 0
        for vx in range(len(self.A)):
            gammas += self.clusteringCoef(vx)
        return gammas / len(self.A)
        
    def clusteringCoef(self, vx):
        """
        Computes the clustering coefficient of a single vertex.
        """
        neighbors = np.where(self.A[vx,:] == 1)[0]
        if vx not in neighborhood:
            neighbors = np.append(neighbors, vx)
        neighborhood = self.A[neighbors, :]
        neighborhood = neighborhood[:, neighbors]
        realEdges = sum(neighborhood) / 2
        possibleEdges = sp.special.binom(len(neighbors), 2)
        return realEdges / possibleEdges        

    def pairwiseDistance(self, vxi, vxj):
        """
        Computes the pairwise distance between vertices i and j.
        """
        d = 1
        N = self.A
        print(N)
        while N[vxi,vxj] == 0:
            print(N)
            N = np.matmul(N, self.A)
            d += 1
        return d
    