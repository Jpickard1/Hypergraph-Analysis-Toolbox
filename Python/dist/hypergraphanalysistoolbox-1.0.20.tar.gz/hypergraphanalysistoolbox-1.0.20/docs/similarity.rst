Similarity Measures
===================
Hypdergraph similariy measures are computed based on ``Hypergraph Dissimilarity Measures."

Direct Measures
*********************
These measures transform uniform hypergraphs to tensors and apply tensor based measures to compare hypergraphs.

Indirect Measures
*****************
These measures decompose the hypergraph to a pairwise tructure and apply standard measures on the pairwise objects.
