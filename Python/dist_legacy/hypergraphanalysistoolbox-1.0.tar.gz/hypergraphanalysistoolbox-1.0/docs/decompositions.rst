Decompositions
==============

Initial hyper graph

.. image:: _static/GH.png
    :align: center

Higher Order Decompositions
***************************

**Adjacency Tensor**

**Line Graph**

.. image:: _static/GL.png
    :align: center

Pairwise Decompositions
***********************

**Clique Expansion**

.. image:: _static/GC.png
    :align: center

**Star Graphs:**

.. image:: _static/GS.png
    :align: center