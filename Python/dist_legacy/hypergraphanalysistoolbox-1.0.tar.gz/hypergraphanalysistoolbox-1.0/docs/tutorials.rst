Tutorials
=========

This page contains a series of demonstrations on how to use HAT.

MATLAB
******
1. `Introduction <https://drive.matlab.com/sharing/7d77b042-c3cb-4ae9-8c06-515089fbccef>`_
2. `Multi-way Interactions <https://drive.matlab.com/sharing/999692ae-26df-4b34-9cd4-c31af10d0bc3>`_

Python
******
