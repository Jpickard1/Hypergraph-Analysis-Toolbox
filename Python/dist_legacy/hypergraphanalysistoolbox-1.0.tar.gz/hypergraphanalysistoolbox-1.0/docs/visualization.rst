Visualization
=============
Incidence matrix visualization is based on Paohvis.

.. image:: _static/IncidenceMatrix.png
    :width: 500
    :alt: Incidence Matrix Visualization
    :align: center
